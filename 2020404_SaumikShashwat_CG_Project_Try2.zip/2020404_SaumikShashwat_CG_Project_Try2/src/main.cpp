// Saumik Shashwat | 2020404 | Computer Graphics Project | Interactive 2D Fractal Generator

#include <iostream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <algorithm>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <GL/gl.h>
#include <GL/glext.h>

const int WIDTH = 1920;
const int HEIGHT = 1080;

//transformation matrices
std::vector<glm::mat4> transformations = {
    glm::scale(glm::mat4(1.0f), glm::vec3(0.8f, 0.6f, 1.0f)),
    glm::translate(glm::mat4(1.0f), glm::vec3(0.1f, 0.3f, 0.0f)),
    glm::rotate(glm::mat4(1.0f), glm::radians(20.0f), glm::vec3(0.0f, 0.0f, 1.0f))
};

//IFS fractal
std::vector<glm::vec2> generateIFSFractal(const std::vector<glm::vec2>& points, const std::vector<glm::mat4>& transformations, int depth) {
    std::vector<glm::vec2> result;
    for (const auto& point : points) {
        for (const auto& transformation : transformations) {
            glm::vec4 transformedPoint = transformation * glm::vec4(point, 0.0f, 1.0f);
            result.push_back(glm::vec2(transformedPoint.x, transformedPoint.y));
        }
    }
    if (depth == 0) {
        return result;
    } else {
        return generateIFSFractal(result, transformations, depth - 1);
    }
}

int depth = 0;

int main() {
    //OpenGL window and set up the rendering context
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return 1;
    }

    glfwWindowHint(GLFW_SAMPLES, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

    GLFWwindow* window = glfwCreateWindow(WIDTH, HEIGHT, "IFS Fractal Generator", nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return 1;
    }
    glfwMakeContextCurrent(window);

    // Initialize GLEW
    glewExperimental = true;
    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW" << std::endl;
        glfwTerminate();
        return -1;
    }

    // Set up the viewport
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);

    // Set up the projection matrix
    glm::mat4 projection = glm::ortho(0.0f, 1.0f, 0.0f, 1.0f, -1.0f, 1.0f);

    // Generate the starting shape for the IFS fractal
    std::vector<glm::vec2> points = {
        glm::vec2(0.0f, 0.0f),
        glm::vec2(1.0f, 0.0f),
        glm::vec2(1.0f, 1.0f),
        glm::vec2(0.0f, 1.0f)
    };


    // vertex buffer and vertex array object
    unsigned int VBO, VAO;
    glGenBuffers(1, &VBO);
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, points.size() * sizeof(glm::vec2), points.data(), GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), 0);
    glEnableVertexAttribArray(0);

    // Set up the vertex shader and fragment shader
    const char* vertexShaderSource = "#version 330 core\n"
                                     "layout (location = 0) in vec2 aPos;\n"
                                     "uniform mat4 projection;\n"
                                     "void main()\n"
                                     "{\n"
                                     "   gl_Position = projection * vec4(aPos.x, aPos.y, 0.0, 1.0);\n"
                                     "}\n\0";
    const char* fragmentShaderSource = "#version 330 core\n"
                                       "out vec4 FragColor;\n"
                                       "void main()\n"
                                       "{\n"
                                       "   FragColor = vec4(0.0f, 1.0f, 1.0f, 1.0f);\n"
                                       "}\n\0";
    

    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glCompileShader(vertexShader);

    GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);
    glCompileShader(fragmentShader);

    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);
    glUseProgram(shaderProgram);

    //projection matrix uniform in the shader program
    unsigned int projectionLoc = glGetUniformLocation(shaderProgram, "projection");

    //callback function for handling user input
    glfwSetKeyCallback(window, [](GLFWwindow* window, int key, int scancode, int action, int mods) {
        if (key == GLFW_KEY_UP && action == GLFW_PRESS) {
            // Increase the depth of the IFS fractal when the up arrow key is pressed
            depth++;
        } else if (key == GLFW_KEY_DOWN && action == GLFW_PRESS) {
            // Decrease the depth of the IFS fractal when the down arrow key is pressed
            depth = std::max(0, depth - 1);
        }
    });

    // Render the fractal in a loop
    while (!glfwWindowShouldClose(window)) {
        // Update the transformation matrices based on user input
        for (int i = 0; i < transformations.size(); i++) {
            if (glfwGetKey(window, GLFW_KEY_1 + i) == GLFW_PRESS) {
                transformations[i] = glm::scale(glm::mat4(1.0f), glm::vec3(1.1f, 1.2f, 1.3f)) * transformations[i];
            }
        }

        // IFS fractal
        std::vector<glm::vec2> fractalPoints = generateIFSFractal(points, transformations, depth);

        // Update the vertex buffer with the new fractal points
        glBindBuffer(GL_ARRAY_BUFFER, VBO);
        glBufferData(GL_ARRAY_BUFFER, fractalPoints.size() * sizeof(glm::vec2), fractalPoints.data(), GL_STATIC_DRAW);

        // Clear the screen and render the fractal
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);
        glUseProgram(shaderProgram);
        glUniformMatrix4fv(projectionLoc, 1, GL_FALSE, glm::value_ptr(projection));
        glBindVertexArray(VAO);
        glDrawArrays(GL_LINE_LOOP, 0, fractalPoints.size());

        // Swap buffers and poll events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Clean up
    glDeleteProgram(shaderProgram);
    glDeleteShader(fragmentShader);
    glDeleteShader(vertexShader);
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);

    glfwTerminate();
    return 0;
}
