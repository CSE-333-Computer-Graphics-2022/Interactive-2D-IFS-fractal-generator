Use up and down arrow keys to move forward and backward the iterations.
